from setuptools import setup

setup(long_description_content_type="text/markdown")
