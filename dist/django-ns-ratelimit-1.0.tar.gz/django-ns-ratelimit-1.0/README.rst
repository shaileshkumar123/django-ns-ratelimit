Ratelimit
=====

ratelimit is a Django app which contains classes, middleware and decorator for ratelimits. 
